""" ddeint/__init__.py """

__all__ = ["ddeint"]

from .ddeint import ddeint

from .version import __version__
